/*
 *
 * Server started at:     4:29
 * Server will end at:    6:29
 *
 */


const serverURL = "http://2f26-2600-8800-7888-7900-dff6-f4b4-ff1b-2a69.ngrok.io";

export default serverURL;