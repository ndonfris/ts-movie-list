/* default colors for application */
const colors = {
    black: '#0D1117',
    barDarker: '#292d3e',
    barLighter: '#3b4252',
    dullWhite: '#bfc7d5',
    brightWhite: '#fff',
    slate: '#C0CAF5'
}


export default colors;

